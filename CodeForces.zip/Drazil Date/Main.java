import java.util.Scanner;
import java.io.IOException;
import java.util.*;
public class Main {
	public static void main (String... st) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int s=sc.nextInt();
		a=Math.abs(a);
		b=Math.abs(b);
		if(s<a+b)
			System.out.println("NO");
		else
		{
			if((s-(a+b))%2==0)
				System.out.println("YES");
			else
				System.out.println("NO");
		}
	}
}