import java.util.Scanner;
import java.io.IOException;
public class Main {
    public static void main (String[] args) throws Exception
    {
        Scanner sc=new Scanner(System.in);
        long n=sc.nextLong();
		String st=String.valueOf(n);
		int luckyNumber=0;
		for(int i=0;i<st.length();i++)
		{
			if(('4'==st.charAt(i)||'7'==st.charAt(i))&&luckyNumber<8)
				luckyNumber++;
		} 
		
		if(luckyNumber==4||luckyNumber==7)
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}