
		int a=sc.nextInt();
		String s=sc.next();
		int remove=0;
		for(int i=0;i<a-1;i++)
		{
			if(s.charAt(i)==s.charAt(i+1))
				remove++;
		}
		System.out.println(remove);
	}
}