import java.io.*;
public class Main {
	public static void main(String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String input=br.readLine();
		String[] array=input.split("[.]");
		if(array[0].charAt(array[0].length()-1)=='9')
			System.out.println("GOTO Vasilisa.");
		else
		{
			if(array[1].charAt(0)>=53)
			{
				char[] ar=array[0].toCharArray();
				int x=Character.getNumericValue(ar[ar.length-1])+1+48;
				ar[ar.length-1]=(char)x;
				String str=new String(ar);
				System.out.println(str);
			}
			else
			{
					System.out.println(array[0]);
			}
		}
	}
}