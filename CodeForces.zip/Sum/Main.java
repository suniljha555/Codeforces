import java.util.Scanner;
import java.io.IOException;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		long n=sc.nextLong();
		if(n%2==0)
		{
			System.out.println(n/2);
		}
		else
		{
			System.out.println(-(n+1)/2);
		}
	}
}