import java.util.Scanner;
import java.io.IOException;
import java.util.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		List<Integer> list=new ArrayList<Integer>(4);
		list.add(a*b*c);
		list.add(a+b+c);
		list.add((a*b)+c);
		list.add((a+b)*c);
		list.add(a*(b+c));
		System.out.println(Collections.max(list));
	}
}