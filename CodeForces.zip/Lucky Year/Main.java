import java.util.*;
public class Main {
	public static void main (String[] args)
	{
		int chk=0;
		HashSet<Character> hs=new HashSet<Character>(4);
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=n+1;i<10000000;i++)
		{
			boolean vo=true;
			String s=String.valueOf(i);
			int len=s.length();
			for(int j=0;j<len;j++)
			{
				if(!hs.add(s.charAt(j)))
				{
					vo=false;
					hs.clear();
					break;
				}
			}
			if(vo==true)
			{
				chk=i;
				break;
			}
		}
		System.out.println(chk);
		
	}
}