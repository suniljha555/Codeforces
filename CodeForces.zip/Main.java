import java.util.Scanner;
import java.io.IOException;
import java.util.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int k=sc.nextInt();
		int n=sc.nextInt();
		int ik=1;
		boolean value=false;
		while(Math.pow(k,ik)<=n)
		{
			if(Math.pow(k,ik)==n)
			{
				System.out.println("YES");
				System.out.println(ik-1);
				value=true;
				break;
			}
			ik++;
		}
		if(!value)
			System.out.println("NO");
	}
}