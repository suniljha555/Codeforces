import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

	public static String output="";
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		String[] integers=bufferedReader.readLine().split(" ");
		int size=Integer.parseInt(integers[0]);
		long total=(long)size*size;
		long temp2=Integer.parseInt(integers[1]);
		if(temp2>100000)
		temp2=Math.min(100000, total);
		//int[][] matrix=new int[Integer.parseInt(integers[1])][2];
		int[] rows=new int[size];
		int[] columns=new int[size];
		for(int i=0;i<temp2;i++)
		{
			String[] powns=bufferedReader.readLine().split(" ");
			//matrix[i][0]=1;
			//matrix[i][1]=1;
			rows[Integer.parseInt(powns[0])-1]=1;
			columns[Integer.parseInt(powns[1])-1]=1;
			print(rows, columns, size, total);
		}
		System.out.println(output.trim());
	}
	
	public static void print(int[] rows,int[] columns,int size,Long total)
	{
		int count=0;
		for(int i=0;i<size;i++)
		{
			for(int j=0;j<size;j++)
			{
				if(rows[i]==1||columns[j]==1)
				{
					count++;
				}
			}
		}
		output+=total-count+" ";
	}

}
