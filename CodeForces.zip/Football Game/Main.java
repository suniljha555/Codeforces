import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Main {
    public static void main (String... s) throws Exception
    {
		BufferedReader br=new BufferedReader (new InputStreamReader(System.in));
		String A=br.readLine();
		if(A.indexOf("0000000")>=0||A.indexOf("1111111")>=0)
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}