import java.io.*;
import java.util.*;
public class Main {
	public static void main (String... arg) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String str=br.readLine();
		int x=str.indexOf("AB");
		int y=str.lastIndexOf("BA");
		//System.out.println(x+"\t"+y);
		if(x!=-1 && y!=-1 && Math.abs(x-y)!=1)
		{
			System.out.println("YES");
		}
		else
			System.out.println("NO");
	}
}