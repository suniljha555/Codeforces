import java.util.Scanner;
import java.io.IOException;
public class Main {
    public static void main (String[] args) throws Exception
    {
        Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int x=sc.nextInt();
		//int[] cards=new int[n];
		int sum=0;
		for(int i=0;i<n;i++)
		{
			//cards[i]=sc.nextInt();
			sum=sum+sc.nextInt();
		}
		if(sum>0)
		{
			x=-x;
			for(int i=0;sum!=0;i++)
			{
				sum=sum
			}
		}
	}
}