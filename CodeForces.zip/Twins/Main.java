import java.io.*;
import java.util.*;
public class Main {
	public static void main (String[] args) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int size=Integer.parseInt(br.readLine());
		String[] input=br.readLine().split(" ");
		int sum=0;
		int[] paise=new int[size];
		for(int i=0;i<size;i++)
		{
			paise[i]=Integer.parseInt(input[i]);
			sum+=paise[i];
		}
		int half=sum/2;
		sum=0;
		int count=0;
		Arrays.sort(paise);
		for(int i=size-1;sum<=half;i--)
		{
			count++;
			sum+=paise[i];
		}
		System.out.println(count);
	}
}