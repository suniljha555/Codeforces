import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Main {
    public static void main (String... s) throws Exception
    {
        Scanner sc=new Scanner(System.in);
        int x=sc.nextInt();
		int y=sc.nextInt();
		int a=sc.nextInt();
		int b=sc.nextInt();
		int gcd=0;
		for(int i=Math.min(x,y);i>0;i--)
		{
			if(x%i==0 && y%i==0)
			{
				gcd=i;
				break;
			}
		}
		int lcm=x*y/gcd;
		System.out.println((b/lcm)-((a-1)/lcm));
	}
}