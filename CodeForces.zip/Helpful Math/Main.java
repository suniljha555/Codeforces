import java.io.*;
import java.util.*;
public class Main {
	public static void main (String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader (System.in));
		String test=br.readLine();
		String[] st=test.split("[+]+");
		int[] arr=new int[st.length];
		for(int i=0;i<st.length;i++)
		{
			arr[i]=Integer.parseInt(st[i]);
		}
		Arrays.sort(arr);
		String str="";
		if(arr.length<2)
			System.out.println(arr[0]);
		else
		{
			for(int i=0;i<st.length-1;i++)
				{
					str=str+arr[i]+"+";
				}
				str=str+arr[arr.length-1];
				System.out.println(str);
		}
		
	}
}