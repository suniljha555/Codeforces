import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		String[] data=bufferedReader.readLine().split(" ");
		int a=Integer.parseInt(data[0]);
		int b=Integer.parseInt(data[1]);
		int remainder=a/b;
		int cost=remainder*Integer.parseInt(data[3]);
		int remainingRides=a%b;
		int minCost=Math.min(remainingRides*Integer.parseInt(data[2]),Integer.parseInt(data[3]) );
		cost+=minCost;
		System.out.println(cost);
		
		
	}

}
