import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		int lngth=Integer.parseInt(bufferedReader.readLine());
		String[] array=bufferedReader.readLine().split(" ");
		int[] ints=new int[lngth];
		for(int i=0;i<lngth;i++)
		{
			ints[i]=Integer.parseInt(array[i]);
		}
		int maxLngth=1;
		int major=0;
		int temp=1;
		try {
			
			for(int i=0;i<lngth-1;i++)
			{
				int min=ints[i];
				if(min<ints[i+1])
				{
					temp++;
					min=ints[i+1];
				}
				else
				{
					maxLngth=Math.max(maxLngth, temp);
					min=ints[i+1];
					temp=1;
				}
			}
			maxLngth=Math.max(maxLngth, temp);
		}
		catch(Exception e)
		{}
		
		System.out.println(maxLngth);
		
	}

}
