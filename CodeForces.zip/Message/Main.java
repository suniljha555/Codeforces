import java.util.*;
import java.io.*;
public class Main {
	public static void main (String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String text=br.readLine();
		String pattern=br.readLine();
		int pLength=pattern.length();
		int tLength=text.length();
		int max=0;
		int count=0;
		if(pattern.length()>text.length())
		{
			pattern=pattern.substring(0,text.length());
		}
		else
		{}
	//System.out.println(pattern);
		//List<Integer> list=new ArrayList<Integer>();
		List<Integer> list2=new ArrayList<Integer>();
		for(int i=0;i<tLength;i++)
		{
			boolean flag=true;
			count=0;
				for(int j=0;j<pLength;j++)
				{
					try {
						if(pattern.charAt(j)!=text.charAt(i+j))
							{
								flag=false;
								break;
							}
					count++;
					}
					catch(Exception e)
					{
						break;
					}
				}
				list2.add(pLength-count);
				//if(flag)
				//list.add(i);
		}
		if(list2.size()==0)
			System.out.println(pLength);
		else
			System.out.println(Collections.min(list2));
		//System.out.println(list2);
	}
}