import java.util.*;
public class Main {
	public static void main (String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		int i=0;int clas=0;
		while(arr[i]==0)
		{
			i++;
		}
		for(int j=i-1;j<n-1;j++)
		{
			if(arr[j]==0 && arr[j+1]==0)
			{}
			else
			{
				clas++;
			}
		}
	}
}