import java.util.*;
import java.lang.*;
import java.io.*;
public class Main {
	public static void main (String[] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int candy=0;
		int noofcandidates=sc.nextInt();
		List<Integer> list=new ArrayList<Integer>();
		for(int i=0;i<noofcandidates;i++)
			list.add(sc.nextInt());
		if(Collections.max(list)==list.get(0) && 1==Collections.frequency(list,Collections.max(list)))
			System.out.println("0");
		else
		{
			while(Collections.max(list)!=list.get(0))
			{
				int maxcandidate=Collections.max(list);
				maxcandidate=maxcandidate-1;
				list.set(list.indexOf(Collections.max(list)),maxcandidate);
				int limak=list.get(0);
				limak=limak+1;
				list.set(0,limak);
				candy++;
			}
			int ch=Collections.frequency(list,Collections.max(list));
			if(ch>1)
			System.out.println(candy+1);
		else 
			System.out.println(candy);
		}
		}
}