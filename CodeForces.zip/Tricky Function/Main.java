import java.io.*;
import java.util.*;
public class Main {
	public static void main (String[] args) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int size=Integer.parseInt(br.readLine());
		String[] input=br.readLine().split(" ");
		int[] a=new int[size];
		for(int i=0;i<size;i++)
		{
			a[i]=Integer.parseInt(input[i]);
		}
		int min=2147483647;
		int fun=0;
		
		System.out.println((int)Math.pow(-12,2));
		for(int i=0;i<size;i++)
		{
			for(int j=0;j<size;j++)
			{
				if(i!=j)
				{
					int x=i-j;
					fun=(int)Math.pow(x,2)+g(i,j,a);
					min=Math.min(min,fun);
					System.out.println("Min: "+min);
				}
			}
		}
		System.out.println(min);
	}
	
	public static int g(int i, int j,int[] a) 
	{
		int max=Math.max(i, j);
		int sum = 0;
		for (int k =Math.min(i, j); k <max ;k++)
			sum = sum + a[k];
		return sum;
	}
	
}