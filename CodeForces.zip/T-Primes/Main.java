import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n=Integer.parseInt(br.readLine());
		String[] arrayElements=br.readLine().split(" ");
		for(int i=0;i<arrayElements.length;i++)
		{
			byte count=0;
			int x=Integer.parseInt(arrayElements[i]);
			for(int j=2;j<x;j++)
			{
				if(x%j==0)
				{
					if(count<2)
						count++;
				}
				if(count==2)
					break;
			}
			if(count==1)
				System.out.println("YES");
			else {
				System.out.println("NO");
			}
		}

	}

}
