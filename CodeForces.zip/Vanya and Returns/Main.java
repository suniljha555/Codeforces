import java.io.IOException;
import java.util.Scanner;
import java.util.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int l=sc.nextInt();
		int[] lightCoordinates=new int[n];
		for(int i=0;i<n;i++)
			lightCoordinates[i]=sc.nextInt();
		Arrays.sort(lightCoordinates);
		int[] diff=new int[n-1];
		for(int i=0;i<n-1;i++)
			diff[i]=lightCoordinates[i+1]-lightCoordinates[i];
		Arrays.sort(diff);
		System.out.println((double)Math.max((double)diff[n-2]/2,Math.max(lightCoordinates[0]-0,l-lightCoordinates[n-1])));
	}
}