import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
public class Main {
	
	List<String> list=new ArrayList<String>();
	int count=0;
	public Main()
	{
		list.add("4");
		list.add("7");
	}
	
    public static void main (String... s) throws Exception
    {
		boolean value=true;
		BufferedReader br=new BufferedReader (new InputStreamReader(System.in));
		int number=Integer.parseInt(br.readLine());
		List<String> list=new Main().generate(String.valueOf(number));
		for(int i=0;i<list.size();i++)
		{
			int divisor=Integer.parseInt(list.get(i));
			if(number%divisor==0)
			{
				value=false;
				System.out.println("YES");
				break;
			}
		}
		if(value)
			System.out.println("NO");
	}
	
	public List<String> generate(String s)
	{
		count++;
		if(s.length()==1)
		{
			return list;
		}
		
		else {
			if(count<=s.length()-1)
			{
				int rise=(int)Math.pow(2,count);
				List<String> temp=new ArrayList<String>();
				int barricade=list.size()-rise;
				for(int i=list.size()-1;i>=barricade;i--)
				{
					temp.add(list.get(i));
				}
				List<String> temp2=new ArrayList<String>();
				for(int i=0;i<rise;i++)
				{
					temp2.add(temp.get(i)+"4");
				}
				for(int i=0;i<rise;i++)
				{
					temp2.add(temp.get(i)+"7");
				}
				list.addAll(temp2);
				temp.clear();
				generate(s);
				
			}
				return list;
		}
	}
	
}