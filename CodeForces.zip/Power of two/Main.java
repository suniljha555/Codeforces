import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		int lngth=Integer.parseInt(bufferedReader.readLine());
		String[] array=bufferedReader.readLine().split(" ");
		int[] ints=new int[lngth];
		for(int i=0;i<lngth;i++)
		{
			ints[i]=Integer.parseInt(array[i]);
		}
			
		int count=0;
				
		for(int i=0;i<lngth;i++)
		{
			for(int j=i+1;j<lngth;j++)
			{
				int n=ints[i]+ints[j];
				if((n & (n - 1)) == 0)
				{
					count++;
				}
			}
		}
		System.out.println(count);
	}
}	