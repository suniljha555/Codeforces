import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Main {
    public static void main (String... s) throws Exception
    {
        Scanner sc=new Scanner(System.in);
        int pylons=sc.nextInt();
		//int first=0;
		//int dollars=0;
		int max=0;
		for(int i=0;i<pylons;i++)
		{
			/*int next=sc.nextInt();
			dollars=dollars+first-next;
			first=next;*/
			max=Math.max(max,sc.nextInt());
		}
		
		System.out.println(max);
	}
}