import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		List<String> listlanguageone=new ArrayList<String>(2);
		List<String> listlanguagetwo=new ArrayList<String>(2);
		for(int i=0;i<m;i++)
		{
			String str=br.readLine();
			listlanguageone.add(str);
			str=br.readLine();
			listlanguagetwo.add(str);
		}
		String st="";
		for(int i=0;i<n;i++)
		{
			String str=br.readLine();
			if((listlanguagetwo.get(listlanguageone.indexOf(str))).length()<str.length())
			{
				st=st+listlanguagetwo.get(listlanguageone.indexOf(str))+" ";
			}
			else
				st=st+str+" ";
			
		}
		st=st.trim();
		System.out.println(st+" ");
	}
}