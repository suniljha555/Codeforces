import java.util.Scanner;
public class Main {
	public static void main (String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] matrix=new int[n];
		for(int i=0;i<n;i++)
			matrix[i]=sc.nextInt();
		int countOdd=0;
		int countEven=0;
		int posE=0;
		int PosO=0;
		for(int i=0;i<n;i++)
		{
			if(matrix[i]%2==0 )
			{
				countEven++;
				posE=i+1;
			}
			else
			{
				countOdd++;
				PosO=i+1;
			}
		}
		if(countEven==1)
			System.out.println(posE);
		else
			System.out.println(PosO);
		byte k=0,l=2;
		System.out.println(matrix[k]+"\t"+matrix[l]);
	}
}