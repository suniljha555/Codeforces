import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Arrays;
import java.lang.String.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		boolean value=false;
		String christmasMen=br.readLine();
		String newyearMen=br.readLine();
		String piledString=br.readLine();
		char[] piled=piledString.toCharArray();
		Arrays.sort(piled);
		piledString=new String(piled);
		String st=christmasMen+newyearMen;
		char[] cocatenate=st.toCharArray();
		Arrays.sort(cocatenate);
		st=new String(cocatenate);
		if(st.length()==piledString.length())
		{
			for(int i=0;i<st.length();i++)
			{
				char ch=piledString.charAt(i);
				char ch2=st.charAt(i);
				if(ch!=ch2)
				{
					value=true;
					break;
				}
			}
			if(value)
					System.out.println("NO");
				else
					System.out.println("YES");
		}
		else
		{
			System.out.println("NO");
		}
	}
}