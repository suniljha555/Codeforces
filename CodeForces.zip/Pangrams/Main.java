import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		String teString="abcdefghijklmnopqrstuvwxyz";
		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		int lngh=Integer.parseInt(bufferedReader.readLine());
		String pangram=bufferedReader.readLine();
		if(lngh<26)
		{
			System.out.println("NO");
		}
		else
		{
			pangram=pangram.toLowerCase();
			boolean[] values=new boolean[26];
			for(int i=0;i<lngh;i++)
			{
				int pos=teString.indexOf(pangram.charAt(i));
				values[pos]=true;
			}
			
			boolean flag=false;
			for(int i=0;i<26;i++)
			{
				if(!values[i])
				{
					flag=true;
				}
			}
			if(flag)
				System.out.println("NO");
			else
				System.out.println("YES");
		}
		
		
	}
	

}
