import java.util.Scanner;
import java.util.*;
public class Main {
	public static void main (String... s)
	{
		Scanner sc=new Scanner(System.in);
		int city=sc.nextInt();
		int[] coordinates=new int[city];
		for(int i=0;i<city;i++)
		{
			coordinates[i]=sc.nextInt();
		}
		//List<Integer> list=new ArrayList<Integer>(5);
		int min=coordinates[1]-coordinates[0];
		int max=coordinates[city-1]-coordinates[0];
		System.out.println(""+min+" "+""+max);
		for(int i=1;i<city-1;i++)
		{
			min=Math.min(coordinates[i+1]-coordinates[i],coordinates[i]-coordinates[i-1]);
			max=Math.max(coordinates[i]-coordinates[0],coordinates[city-1]-coordinates[i]);
			System.out.println(""+min+" "+""+max);
			//list.clear();
		}
		min=coordinates[city-1]-coordinates[city-2];
		max=coordinates[city-1]-coordinates[0];
		System.out.println(""+min+" "+""+max);
	}
}