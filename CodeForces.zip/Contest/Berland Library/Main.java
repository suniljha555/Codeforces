import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Main {
    public static void main (String... s) throws Exception
    {
        Scanner sc=new Scanner(System.in);
        int log=sc.nextInt();
        //System.out.println(log);
        //BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int count=0;
        for(int x = 0; x <log; x++)
        {
            String st=sc.next();
            if(st.contains("-"))
                count++;
        }
        System.out.println(count);
    }
}