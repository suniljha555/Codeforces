import java.util.*;
public class Main {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		List<Integer> list1=new ArrayList<Integer>(1);
		List<Integer> list2=new ArrayList<Integer>(1);
		List<Integer> list3=new ArrayList<Integer>(1);
		boolean value=false;
		for(int i=0;i<n;i++)
		{
			list1.add(sc.nextInt());
		}
		for(int i=0;i<n-1;i++)
		{
			list2.add(sc.nextInt());
		}
		for(int i=0;i<n-2;i++)
		{
			list3.add(sc.nextInt());
		}
		Collections.sort(list1);
		Collections.sort(list2);
		Collections.sort(list3);
		int index=0;
		for(int i=0;i<n-1;i++)
		{
			if(list1.get(i)==list2.get(i))
			{
				list1.remove(i);
				System.out.println(list1);
			}
			else{
				break;
			}
		}
			System.out.println(list1.get(0));
		for(int i=0;i<n-2;i++)
		{
			if(list2.get(i)==list3.get(i))
			{
				list2.remove(i);
				System.out.println(list2);
			}
			else{
				break;
			}
		}
		System.out.println(list2.get(0));
	}
}