import java.util.*;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import java.math.*;
public class Main {
    public static void main (String[] args) throws Exception
    {
		List<Integer> list1=new ArrayList<Integer>();
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
		int m=sc.nextInt();
		for(int i=0;i<m;i++)
		{
			List<Integer> list=new ArrayList<Integer>();
			for(int j=0;j<n;j++)
			{
				list.add(sc.nextInt());
			}
			
			list1.add(list.indexOf(Collections.max(list)));
			list.clear();
		}
		List<Integer> list2=new ArrayList<Integer>();
		for(int i=0;i<n;i++)
		{
			list2.add(Collections.frequency(list1,i));
		}
		System.out.println(list2.indexOf(Collections.max(list2))+1);
	}
}