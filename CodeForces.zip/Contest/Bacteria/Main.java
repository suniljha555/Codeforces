import java.util.*;
public class Main {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=0;
		if((n & (n - 1)) == 0)
		{
			System.out.println("1");
		}
		else 
		{
			while(Math.pow(2,m)<=n/2)
			{
				m++;
			}
			System.out.println((n/(int)(Math.pow(2,m)))+n-(int)(Math.pow(2,m)));
		}
	}
}