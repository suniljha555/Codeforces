import java.io.IOException;
import java.util.Scanner;
import java.util.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int nA=sc.nextInt();
		int nB=sc.nextInt();
		int[] A=new int[nA];
		int[] B=new int[nB];
		int k=sc.nextInt();
		int m=sc.nextInt();
		for(int i=0;i<nA;i++)
			A[i]=sc.nextInt();
		for(int i=0;i<nB;i++)
			B[i]=sc.nextInt();
		int kcount=0;
		for(int i=0;i<k;i++)
		{
			for(int j=0;j<m;k++)
			{
				if(A[i]<B[j])
					kcount++;
			}
		}
		if(kcount==k && kcount>=m)
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}