import java.util.*;
public class Main {
	public static void main (String... s)
	{
		Scanner sc=new Scanner(System.in);
		int hero=0;
		int n=sc.nextInt();
		int count=0;
		int countv=0;
		List<Integer> list=new ArrayList<Integer>(1);
		int x=sc.nextInt();
		for(int i=1;i<=n;i++)
			if(x%i==0)
				list.add(i);
			for(int i=0;i<list.size();i++)
			{
				for(int j=0;j<list.size();j++)
					countv=( list.get(i)*list.get(j) == x ) ? count++ :hero++;
			}
			System.out.println(count);
	}
}