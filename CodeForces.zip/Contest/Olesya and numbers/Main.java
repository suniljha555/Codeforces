import java.util.*;
public class Main {
	public static void main (String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int t=sc.nextInt();
		boolean value=false;
		String s=t+"";
		int digit=1;
		if(n==1 && t==10)
			System.out.println("-1");
		else
		{
			if(t==10)
			digit=2;
		for(int i=digit;i<n;i++)
			s+="0";
		System.out.println(s);
		}
	}
}