import java.io.IOException;
import java.util.Scanner;
import java.util.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int nA=sc.nextInt();
		int s=sc.nextInt();
		List<Integers> list1=new ArrayList<Integers>(5);
		List<Integers> list2=new ArrayList<Integers>(5);
		for(int i=0;i<nA;i++)
		{
			if(sc.next()=='B')
				list1.add(sc.nextInt()*sc.nextInt());
			else
				list2.add(sc.nextInt()*sc.nextInt());
		}
		Collections.sort(list1);
		Collections.sort(list2);
		System.out.println(Collections.max(list1));
		System.out.println(Collections.max(list1));
	}
}