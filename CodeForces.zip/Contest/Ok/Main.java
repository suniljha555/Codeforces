import java.util.*;
public class Main {
	public static void main(String... s)
	{
		Scanner sc=new Scanner(System.in);
		String[] board=new String[8];
		for(int i=0;i<8;i++)
			board[i]=sc.nextLine();
		char[][] newbord=new char[8][8];
		for(int i=0;i<8;i++)
			newbord[i]=board[i].toCharArray();
		int wPos=-1;
		boolean value=true;
		for(int i=0;i<8 & wPos==-1;i++)
		{
			wPos=-1;
			for(int j=0;j<8;j++)
			{
				if(newbord[i][j]=='W')
				{
					for(int k=i-1;k>=0;k--)
					{
						if(newbord[k][j]=='B')
						{
							value=false;
							break;
						}
					}
					if(value)
						wPos=i;
					else
						wPos=-1;
				}
			}
		}
		int bPos=-1;
		value=true;
		for(int i=7;i>=0 & bPos==-1;i--)
		{
			bPos=-1;
			for(int j=7;j>=0;j--)
			{
				if(newbord[i][j]=='B')
				{
					for(int k=i+1;k<8;k++)
					{
						if(newbord[k][j]=='W')
						{
							value=false;
							break;
						}
					}
				}
				System.out.println(i);
				if(value)
					bPos=7-i;
				else
					bPos=-1;
			}
		}
		System.out.println(bPos);
		System.out.println(wPos);
		if(bPos<wPos)
			System.out.println("B");
		else
			System.out.println("A");
	}
}