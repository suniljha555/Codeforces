import java.util.*;
public class Main {
	public static void main (String... s)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int x=sc.nextInt();
		int count=x;
		int[] arr=new int[n];
		for(i=0;i<n;i++)
			arr[i]=sc.nextInt();
		for(int i=1;i<n;i++)
		{
			count=x*i;
			while(sum!=x)
			{
				count=count-arr[i];
			}
		}
	}
}