import java.util.*;
import java.io.*;
public class Main {
    public static void main (String... st) throws Exception
    {
		Scanner sc=new Scanner(System.in);
		float l=sc.nextFloat();
		float p=sc.nextFloat();
		float q=sc.nextFloat();
		float up=(p/q)*l;
		float down=(p+q)/q;
		float dist=up/down;
		System.out.println(dist);
	}
}