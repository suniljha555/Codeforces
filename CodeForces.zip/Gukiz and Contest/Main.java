import java.io.*;
import java.util.*;
public class Main {
	public static void main (String... arg) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n=Integer.parseInt(br.readLine());
		String str=br.readLine();
		String[] ratings=str.split("[ ]+");
		int arrayLength=ratings.length;
		int[] array=new int[arrayLength];
		String str2="";
		for(int i=0;i<arrayLength;i++)
		{
			array[i]=Integer.parseInt(ratings[i]);
			str2+=ratings[i];
		}
		System.out.println(str2);
		//int[] arrayCopy=array;
		
		
	}
}