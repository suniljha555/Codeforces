import java.io.*;
public class Main {
	public static void main (String[] args) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String[] input=br.readLine().split(" ");
		int size=Integer.parseInt(input[0]);
		int time=Integer.parseInt(input[1]);
		char[] read=br.readLine().toCharArray();
		
		for(int j=0;j<time;j++)
		{
			for(int i=0;i<size-1;i++)
				{
					if(read[i]=='B' && read[i+1]=='G')
					{
						read[i]='G';
						read[i+1]='B';
						i++;
					}
				}
		}
		System.out.println(new String(read));
	}
}