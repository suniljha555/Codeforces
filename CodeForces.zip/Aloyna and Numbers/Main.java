import java.io.*;
public class Main {
	public static void main (String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader (System.in));
		String[] str=br.readLine().split(" ");
		Long n=Long.parseLong(str[0]);
		Long m=Long.parseLong(str[1]);
		int count=0;
		Long total=n*m;
		System.out.println(Math.round((double)total/5));
	}
}