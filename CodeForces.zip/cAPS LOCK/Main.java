import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Main {
    public static void main (String... s) throws Exception
    {
		BufferedReader br=new BufferedReader (new InputStreamReader(System.in));
		String st=br.readLine();
		if(isUpperCase(st,0))
		{
			System.out.println(st.toLowerCase());
		}
		else if(isUpperCase(st,1) )
		{
			st=st.toLowerCase();
			char[] stArray=st.toCharArray();
			stArray[0]=Character.toUpperCase(stArray[0]);
			System.out.println(new String(stArray));
		}
		else
			System.out.println(st);
		
	}
	
	public static boolean isUpperCase(String s,int start)
	{
		for (int i=start; i<s.length(); i++)
			{
				if (Character.isLowerCase(s.charAt(i)))
				{
					return false;
				}
		}
		return true;
	}
}


//http://codeforces.com/problemset/problem/131/A