import java.io.*;
import java.util.*;
public class Main {
	public static void main (String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader (System.in));
		int n=Integer.parseInt(br.readLine());
		String[] str=br.readLine().split(" ");
		List<Integer> list=new ArrayList<Integer>();
		for(int i=0;i<str.length;i++)
		{
			list.add(Integer.parseInt(str[i]));
		}
		boolean value=false;
		Collections.sort(list);
		int last=list.get(n-1);
		for(int i=last;i>0;i--)
		{
			if(!list.contains(i))
			{
				value=true;
				System.out.println(i);
				break;
			}
		}
		
		if(!value)
		{
			System.out.println(list.get(n-1)+1);
		}
	}
}