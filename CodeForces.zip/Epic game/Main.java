import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Main {
    public static void main (String... s) throws Exception
    {
        Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int n=sc.nextInt();
		System.out.println(Whowinsgame(a,b,n));
	}
	public static int Whowinsgame(int a,int b,int n)
	{
		boolean value=true;
		int check=a;
		while(n>0)
			{
				for(int i=Math.min(check,n);i>0;i--)
					{
						if(check%i==0 && n%i==0)
							{
								n=n-i;
								value=!value;
								break;
							}
					}
					if(value)
						check=a;
					else
						check=b;
			}
		if(!value)
			return 0;
		else
			return 1;
	}
}