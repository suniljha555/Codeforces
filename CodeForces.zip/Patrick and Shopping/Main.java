import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main (String[] args)
	{
		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		int d1,d2,d3;
		String[] distances;
		try {
			distances=bufferedReader.readLine().split(" ");
			d1=Integer.parseInt(distances[0]);
			d2=Integer.parseInt(distances[1]);
			d3=Integer.parseInt(distances[2]);
			int totd1=2*(d1+d2);
			int totd2=2*(d1+d3);
			int totd3=2*(d2+d3);
			int totd4=d1+d2+d3;
			int min=Math.min(totd1, totd2);
			int min2=Math.min(min, totd3);
			int finalMin=Math.min(min2, totd4);
			System.out.println(finalMin);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
