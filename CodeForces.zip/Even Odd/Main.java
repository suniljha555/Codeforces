import java.util.Scanner;
public class Main {
	public static void main (String[] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		long N=sc.nextLong();
		long K=sc.nextLong();
		if(N%2==0 )
		{
			if(K>N/2)
				System.out.println(2+(K-(N/2)-1)*2);
			else
				System.out.println(1+(K-1)*2);
		}
		else
		{
			if(K>(N/2)+1)
				System.out.println(2+(K-1-(N/2)-1)*2);
			else
				System.out.println(1+(K-1)*2);
		}
	}
}