import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		int distance=Integer.parseInt(bufferedReader.readLine());
		if(distance>5)
		{
			if(distance%5==0)
				System.out.println((distance/5));
			else
				System.out.println((distance/5)+1);
		}
		else
			System.out.println("1");
		
	}
}