import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int test=0;
		int output=0;
		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		try {
			test=Integer.parseInt(bufferedReader.readLine());
			for(int i=0;i<test;i++)
			{
				String tString=bufferedReader.readLine();
				if(tString.charAt(1)=='+')
				output+=1;
				else {
					output-=1;
				}
			}
			
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(output);
		
		
		
	}
}
