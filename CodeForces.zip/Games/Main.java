import java.util.Scanner;
public class Main {
	public static void main (String... s)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[][] fixation=new int[n][2];
		for(int i=0;i<n;i++)
		{
			fixation[i][0]=sc.nextInt();
			fixation[i][1]=sc.nextInt();
		}
		int count=0;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(fixation[i][0]==fixation[j][1])
					count++;
			}
		}
		System.out.println(count);
	}
}