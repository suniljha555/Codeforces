import java.util.*;
import java.lang.*;
import java.io.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		long k=sc.nextLong();
		long temp=0,temp2=1;
		int i=1;
		long fibo=0;
		if(k==0)
			System.out.println("0");
		else if(k==1)
			System.out.println("1");
		else
		{
			while(fibo<k)
		{
			temp=temp2;
			temp2=fibo;
			fibo=temp+temp2;
			i++;
		}
		if(fibo==k)
		System.out.println(i);
	else
		System.out.println("-1");
		}
	}
}