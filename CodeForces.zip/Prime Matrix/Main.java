/* package whatever; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Ideone
{
	//boolean[] array=new boolean[100001];
	public static void main (String[] args) throws java.lang.Exception
	{
		// your code goes here
		int min=0;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String[] arr=br.readLine().split(" ");
		int n=Integer.parseInt(arr[0]);
		int m=Integer.parseInt(arr[1]);
		int[][] matrix=new int[n][m];
		operation op=new operation();
		op.start();
		for(int i=0;i<n;i++)
		{
			String[] num=br.readLine().split(" ");
			//System.out.println(num[1]);
			for(int j=0;j<m;j++)
			{
				int x=Integer.parseInt(num[j]);
			//	System.out.println(op.array[5]);
				if(op.array[x])
				{
					for(int k=x;k>=2;k--)
					{
						if(!op.array[k])
						{
							min=x-k;
							break;
						}
					}
					System.out.println(min);
					for(int l=x;l<=100000;l++)
					{
						if(!op.array[l])
						{
							if(x-l<min)
								matrix[i][j]=l-x;
							else
								matrix[i][j]=min;
							break;
						}
					}
				}
				else
				{
					matrix[i][j]=0;
				}
			}
		}
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			System.out.print(matrix[i][j]+"\t");
			System.out.println();
		}
	}
}


class operation extends Thread {
	boolean[] array=new boolean[100001];
	
	
	public void run()
	{
		array[0]=true;
		array[1]=true;
		for(int i=2;i*i<=100000;i++)
		{
			if(!array[i])
			{
				for(int j=i;i*j<=100000;j++)
					{
						array[i*j]=true;
					}
			}
		}
	}
}