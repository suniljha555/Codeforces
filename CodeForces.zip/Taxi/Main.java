import java.io.*;
import java.util.*;
public class Main {
	public static void main (String... arg) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n=Integer.parseInt(br.readLine());
		int[] array=new int[5];
		String s[]=br.readLine().split(" ");
		for(int i=0;i<n;i++)
		{
			case 1:array[]
			
		}
		
	}
}