class Solution {
	public static void main (String... s)
	{
		Solution sol=new Solution();
		sol.cutEven(25);
	}
	boolean cutEven(int num)
}