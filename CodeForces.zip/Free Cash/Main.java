import java.io.*; 
public class Main {
	public static void main (String[] args) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int x=Integer.parseInt(br.readLine());
		int temp=1;
		String[] array=new String[x];
		for(int i=0;i<x;i++)
		{
			array[i]=br.readLine();
		}
		for(int i=0;i<x-1;i++)
		{
			
			if(array[i].equals(array[i+1]))
				temp=temp+1;
		}
		System.out.println(temp);
	}
}