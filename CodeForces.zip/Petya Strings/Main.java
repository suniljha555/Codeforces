import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Main {
    public static void main (String... s) throws Exception
    {
		BufferedReader br=new BufferedReader (new InputStreamReader(System.in));
		String A=br.readLine();
		String B=br.readLine();
		if(0==A.compareToIgnoreCase(B))
			System.out.println("0");
		else if(0>A.compareToIgnoreCase(B))
			System.out.println("-1");
		else
			System.out.println("1");
	}
}