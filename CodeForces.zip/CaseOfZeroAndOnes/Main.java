import java.io.*;
import java.util.*;
public class Main {
	public static void main (String... arg) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n=Integer.parseInt(br.readLine());
		String s=br.readLine();
		while(true)
		{
			int x=0;
			x=s.indexOf("01");
			if(x==-1)
			{
				x=s.indexOf("10");
			}
			if(x==-1)
			{
				break;
			}
			else
			{
			if(x!=0)
				s=s.substring(0,x)+s.substring(x+2,n);
			else
				s=s.substring(x+2,n);
			n=n-2;
			
			}
		}
		System.out.println(n);
	}
}