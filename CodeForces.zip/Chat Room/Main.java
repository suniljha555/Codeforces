import java.util.Scanner;
public class Main {
	public static void main (String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String st="hello";
		boolean value=false;
		int count=0;
		for(int i=0;i<s.length() && count<5;i++)
		{
			if(s.charAt(i)==st.charAt(count))
			{
				count++;
			}
		}
		if(count==5)
			System.out.println("YES");
		else 
			System.out.println("NO");
	}
}