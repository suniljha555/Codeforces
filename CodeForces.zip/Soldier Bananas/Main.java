import java.util.Scanner;
import java.io.IOException;
import java.util.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int k=sc.nextInt();
		int n=sc.nextInt();
		int w=sc.nextInt();
		int sum=k*(w*(w+1)/2);
		if(sum>n)
		System.out.println(sum-n);
		else
		{
			System.out.println("0");
		}
		
	}
}