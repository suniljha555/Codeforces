class Node {
	int data;
	Node next;
	Node prev;
	public Node (int data)
	{
		this.data=data;
	}
}



public class Main {
	public static void main (String[] args)
	{
		Node head=null;
		System
	}
}