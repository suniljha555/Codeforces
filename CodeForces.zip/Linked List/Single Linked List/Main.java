import java.io.*;


class Node {
	int data;
	Node next;
	public Node(int data)
	{
		this.data=data;
	}
	public int returnData()
	{
		return data;
	}
}


public class Main {
	Node head=null;
	public static void main (String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Main mn=new Main();
		while(true)
		{
			System.out.println("Enter your choice:");
			System.out.println("1.Insert");
			System.out.println("2.Print");
			System.out.println("3.Delete");
			System.out.println("4.Sort");
			System.out.println("5.Exit");
			int ch=Integer.parseInt(br.readLine());
			switch(ch)
			{
				case 1:mn.create();
					break;
				case 2:mn.print();
					break;
				case 3:mn.delete();
					break;
				case 4:mn.sort();
					break;
				case 5:System.exit(0);
				default:System.out.println("Enter a valid choice:");
			}
		}
	}
	
	
	public void sort()
	{
		Node temp=head;
		while(temp!=null)
		{
			int x=temp.data;
			Node temp2=temp.next;
			Node temp3=temp.next;
			while(temp3!=null)
			{
				if(x>temp3.data)
				{
					//x=temp3.data;
					temp2=temp.next;
				}
				temp3=temp3.next;
			}
			if(temp2==head)
			{
				head=temp2;
				temp3.next=temp.next;
			}
			else
			{
				temp.next=temp2;
			}
			temp=temp.next;
		}
	}
	
	
	public void delete() throws IOException
	{
		Node temp=head;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		new Main().print();
		System.out.println("Enter the element to be removed.");
		int thatNum=Integer.parseInt(br.readLine());
		while(temp.data!=thatNum)
		{
			temp=temp.next;
		}
		if(temp==head)
		{
			head=temp.next;
		}
		else
		{
			Node nx=temp.next;
			temp.next=nx.next;
		}
	}
	
	
	
	public void print()
	{
		Node temp=head;
		//System.out.println(head);
		System.out.println();
		if(temp==null)
		{
			System.out.println("Linked List is empty.");
		}
		
		else
		{
			while(temp!=null)
			{
				System.out.print(temp.data+"  ");
				temp=temp.next;
			}
		}
		System.out.println();
	}
	
	
	public void create () throws IOException
	{
		int count=1;
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the data element of linked list.");
		int n=Integer.parseInt(br.readLine());
		Node nn=new Node(n);
		//System.out.println(head);
		if(head==null)
		{
			//System.out.println("Hello");
			head=nn;
			nn.next=null;
		}
		
		else
		{
			Node temp=head;
			Node temp2=null;
			while(temp.next!=null)
			{
				temp=temp.next;
				count++;
			}
			temp.next=nn;
			nn.next=null;
		}
		//System.out.println(head);
		System.out.println("Total Number of elements in linked list:"+count);
	}
	
}