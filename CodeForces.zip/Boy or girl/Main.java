import java.util.*;
import java.io.*;
public class Main {
    public static void main (String... st) throws Exception
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String s=br.readLine();
		new Main().check(s);
	}
	void check(String sr)
	{
		char ch[]=sr.toCharArray();
		HashSet<Character> list=new HashSet<Character>();
		for(int i=0;i<sr.length();i++)
		{
			list.add(sr.charAt(i));
		}
		if(list.size()%2==0)
			System.out.println("CHAT WITH HER!");
		else
			System.out.println("IGNORE HIM!");
	}
}