import java.util.*;
import java.io.*;
public class Main {
    public static void main (String... st) throws Exception
    {
		Scanner sc=new Scanner(System.in);
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int ch=sc.nextInt();
		String s=br.readLine();
		boolean value=true;
			if(s.indexOf("10")*s.indexOf("01")==1)
			{
				System.out.println(s.length());
			}
			else
			{
				new Main().Stringcheck(s);
			}
	}
	void Stringcheck(String s)
	{
		while(s.indexOf("10")!=-1)
		{
			int x=s.indexOf("10");
			s=s.substring(0,x)+s.substring(x+2,s.length());
		}
		while(s.indexOf("01")!=-1)
		{
			int x=s.indexOf("10");
			s=s.substring(0,x)+s.substring(x+2,s.length());
		}
		System.out.println(s.length());
	}
}