import java.util.Scanner;
import java.io.IOException;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int[] arr=new int[4];
		for(int i=0;i<4;i++)
			arr[i]=sc.nextInt();
			int count=0;
			int d=sc.nextInt();
		for(int i=1;i<=d;i++)
		{
			if(i%arr[0]==0||i%arr[1]==0||i%arr[2]==0||i%arr[3]==0)
				count++;
		}
		System.out.println(count);
	}
}