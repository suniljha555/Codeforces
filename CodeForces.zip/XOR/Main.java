import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.math.*;
public class Main {
    public static void main (String... s) throws Exception
    {
        Scanner sc=new Scanner(System.in);
        int x=sc.nextInt();
		int[] xArray=new int[x];
		for(int i=0;i<x;i++)
			xArray[i]=sc.nextInt();
		int operations=sc.nextInt();
		for(int i=0;i<operations;i++)
		{
			if(sc.nextInt()==1)
			{
				int l=sc.nextInt();
				int r=sc.nextInt();
				long sum=0;
				for(int j=l-1;j<r;j++)
					sum=sum+xArray[j];
				System.out.println(sum);
				
			}
			else
			{
				int l=sc.nextInt();
				int r=sc.nextInt();
				int xor=sc.nextInt();
				for(int j=l-1;j<r;j++)
					xArray[j]=xArray[j]^xor;
			}
		}
	}
}