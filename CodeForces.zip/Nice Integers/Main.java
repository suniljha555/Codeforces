import java.util.Scanner;
import java.io.IOException;
import java.util.*;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int sum=0;
		for(int i=b;;i++)
		{
			int quotnt=i/b;
				int mod=i%b;
			if(i%b!=0)
				if(quotnt/mod<=a && quotnt/mod>=1)
				sum=sum+i;
			else if(quotnt/mod>a)
				break;
			
		}
		System.out.println(sum);
	}
}