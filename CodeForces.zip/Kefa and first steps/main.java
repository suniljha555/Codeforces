import java.util.Scanner;
public class main {
	public static void main (String... s)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		boolean value=false;
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		int max=1,max1=1;
		for(int i=0;i<n-1;i++)
		{
			if(arr[i]<=arr[i+1])
			{
				max1++;
			}
			else
			{
				max=Math.max(max,max1);
				max1=1;
			}
			max=Math.max(max,max1);
		}
		System.out.println(max);
	}
}