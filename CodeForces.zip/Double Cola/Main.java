import java.util.*;
public class Main {
	public static void main (String[] args)
	{
		List<String> list=new ArrayList<String>(5);
		list.add("Sheldon");
		list.add("Leonard");
		list.add("Penny");
		list.add("Rajesh");
		list.add("Howard");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		//Random rand = new Random();
		//int  n = rand.nextInt(1000000000) + 1;
		//System.out.println(n);
		
		if(n<=5)
		{
			System.out.println(list.get(n-1));
		}
		else
		{
			int counter=5;
			while(counter*2<n)
		{
			counter=counter*2;
		}
		int noOfpersoninQueue=counter/5;
		int peco=n-counter;
		for(int i=0;i<5;i++)
		{
			if(peco<=noOfpersoninQueue){
				System.out.println(list.get(i));
				break;
			}
			peco=peco-noOfpersoninQueue;
		}
		}
	}
}