import java.util.Scanner;
import java.io.IOException;
public class Main {
	public static void main (String... s) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int sqrt=(int)Math.sqrt(n);
		boolean[] composite=new boolean[n];
		for(int i=2;i<=sqrt;i++)
		{
			for(int k=i*i;k<n;k+=i)
			{
				composite[k]=true;
			}
		}
		for(int i=4;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(composite[i] && composite[j])
				{
					if(i+j==n){
						System.out.println(""+i+" "+""+j);
						i=n;
						break;
					}
				}
			}
		}
	}
}