import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

	BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		String[] data=bufferedReader.readLine().split(" ");
		int s=Integer.parseInt(data[0]);
		int n=Integer.parseInt(data[1]);
		int[][] array=new int[n][2];
		for(int i=0;i<n;i++)
		{
			String[] nums=bufferedReader.readLine().split(" ");
			array[i][0]=Integer.parseInt(nums[0]);
			array[i][1]=Integer.parseInt(nums[1]);
		}
		boolean value=true;
		int dirikoPower=s;
		for(int i=0;i<n && value;i++)
		{
			value=false;
			for(int j=0;j<n;j++)
			{
				if(array[j][0]<dirikoPower)
				{
					dirikoPower+=array[j][1];
					value=true;
					array[j][0]=100000;
					break;
				}
			}
		}
		value=true;
		for(int i=0;i<n;i++)
		{
			if(array[i][0]!=100000)
			{
				System.out.println("NO");
				value=false;
				break;
			}
		}
		
		if(value)
			System.out.println("YES");

		
	}

}
