import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		int x=Integer.parseInt(bufferedReader.readLine());
		String[] integers=bufferedReader.readLine().split(" ");
		int[] array=new int[x];
		int sum=0;
		for(int i=0;i<x;i++)
		{
			array[i]=Integer.parseInt(integers[i]);
			sum+=array[i];
		}
		int z=x/2;
		int total=sum/z;
		int count=0;
		for(int i=0;i<z;i++)
		{
			
			int sumInd=0;
			for(int j=x-1;j>=0;j--)
			{
				if(array[j]!=0)
				{
					sumInd=array[j];
					array[j]=0;
					count=j;
					break;
				}
			}
			
			for(int j=0;j<x;j++)
			{
				if(sumInd+array[j]==total)
				{
					System.out.println((count+1)+"\t"+(j+1));
					array[j]=0;
					break;
				}
			}
		}
	}

}
