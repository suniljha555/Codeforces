import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
public class Main {
	public static void main (String... s) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String str=br.readLine();
		if(Character.isUpperCase(str.charAt(0)))
			System.out.println(str);
		else{
			char ch=Character.toUpperCase(str.charAt(0));
			StringBuilder st2 = new StringBuilder(str);
			st2.setCharAt(0, ch);
			System.out.println(st2);
		}
	}
}